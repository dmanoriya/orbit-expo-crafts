<?php

namespace HeadlessCommerceCore\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class HomepageManager {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_admin_menu' ), 10 );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
	}

	public static function add_admin_menu() {
		add_submenu_page(
			'headless-commerce-core',
			'Homepage Content Builder',
			'Homepage Builder',
			'manage_options',
			'hcc-homepage-builder',
			array( __CLASS__, 'render_homepage_builder_page' )
		);
	}

	public static function register_settings() {
		register_setting( 'hcc_homepage_options_group', 'hcc_homepage_options' );
	}

	public static function get_homepage_data() {
		$defaults = array(
			// Hero
			'hero_eyebrow'          => 'THE LIVING GALLERY',
			'hero_title'            => 'Objects with a life beyond trends.',
			'hero_accent'           => 'beyond trends.',
			'hero_lede'             => 'Handcrafted furniture and décor, shaped by enduring materials and thoughtful detail.',
			'hero_bg_mode'          => 'image',
			'hero_bg_image'         => site_url( '/wp-content/uploads/hero_bg.webp' ),
			'hero_bg_color'         => '#F5F2EC',
			'hero_overlay_opacity'  => '0',
			'hero_cta1_text'        => 'EXPLORE THE COLLECTION',
			'hero_cta1_url'         => '/collections',
			'hero_cta2_text'        => 'DISCOVER OUR CRAFT',
			'hero_cta2_url'         => '/about',
			
			// Stats
			'stat1_number'      => '3,20,000',
			'stat1_label'       => 'SQ. FT. WORKS',
			'stat2_number'      => '1,400+',
			'stat2_label'       => 'CRAFTSMEN & STAFF',
			'stat3_number'      => '24',
			'stat3_label'       => 'EXPORT MARKETS',
			'stat4_number'      => '98%',
			'stat4_label'       => 'ON-TIME DELIVERY',

			// Work With Us Section
			'work_title'         => "Choose How You'd Like to Work With Us",
			'work_card1_eyebrow' => 'SHOP FURNITURE',
			'work_card1_title'   => 'Individual Pieces, Made to Belong',
			'work_card1_desc'    => 'Discover considered furniture and objects for one room, one corner, or the whole home.',
			'work_card1_cta'     => 'EXPLORE THE COLLECTION',
			'work_card1_url'     => '/collections',
			'work_card1_image'   => '/Explore_collection.webp',

			'work_card2_eyebrow' => 'COMPLETE PROJECTS',
			'work_card2_title'   => 'Spaces, Crafted from Brief to Installation',
			'work_card2_desc'    => 'Partner with our project team for custom furniture, material development, production and complete execution.',
			'work_card2_cta'     => 'VISIT THE TRADE DESK',
			'work_card2_url'     => '/discuss-projects',
			'work_card2_image'   => '/Project.webp',

			// Feature Track Cards
			'track1_title'      => 'Direct contract projects',
			'track1_desc'       => 'Full-scope loose furniture & fixed joinery built to architect specifications.',
			'track1_points'     => "Kiln-dried & anti-borer treated timber\nCustom stain matching & fabric approvals\nCAD/3D shop drawing review\nDoor-to-door freight & logistics",

			'track2_title'      => 'Turnkey plug-in packages',
			'track2_desc'       => 'Pre-engineered room packages for rapid hotel guestroom & restaurant fit-outs.',
			'track2_points'     => "FSC certified wood options\nNo minimum order quantity\n45-day turnaround guarantee\nSite installation support team",

			// Categories
			'cat_eyebrow'       => 'PRODUCT CATEGORIES · DIRECT FACTORY COLLECTIONS',
			'cat_title'         => 'Categories. Every piece a home needs',
			'cat_desc'          => 'From solid wood seating to custom storage furniture, every piece is made to order in our manufacturing facilities.',

			// Project Spaces / Domains
			'seg_eyebrow'       => 'PROJECT DOMAINS',
			'seg_title'         => 'Shop the way a project actually gets specified.',
			'seg_desc'          => 'Furniture engineered for commercial spaces with heavy contract use standards.',
			'seg1_name'         => 'Hotel Guestrooms',
			'seg1_image'        => '/project-categories/hotel-guestrooms.webp',
			'seg1_url'          => '/collections?seg=Hotel%20Guestrooms',
			'seg2_name'         => 'Hotel Lobby',
			'seg2_image'        => '/project-categories/hotel-lobby.webp',
			'seg2_url'          => '/collections?seg=Hotel%20Lobby',
			'seg3_name'         => 'Restaurant',
			'seg3_image'        => '/project-categories/restaurant.webp',
			'seg3_url'          => '/collections?seg=Restaurant',
			'seg4_name'         => 'Café & Bistro',
			'seg4_image'        => '/project-categories/cafe-bistro.webp',
			'seg4_url'          => '/collections?seg=Caf%C3%A9%20%26%20Bistro',

			// Featured Designs
			'feat_eyebrow'      => '',
			'feat_title'        => 'A few we are proud of this season.',
			'feat_desc'         => 'Popular baseline designs ready for customization to your project’s material, fabric, and dimensional specifications.',
			'feat_cta_text'     => 'Explore Collection',
			'feat_cta_url'      => '/collections',

			// 5 Steps
			'step_eyebrow'      => 'FACTORY PROCESS',
			'step_title'        => 'Five steps from your drawing to your floor.',
			'step1_title'       => 'Enquiry',
			'step1_desc'        => 'Send drawings, BOQ, or shortlist catalog items for quotation.',
			'step2_title'       => 'Specs',
			'step2_desc'        => 'CAD shop drawings, timber samples, and fabric approvals.',
			'step3_title'       => 'Prototype',
			'step3_desc'        => 'First-piece inspection before bulk production begins.',
			'step4_title'       => 'Manufacture',
			'step4_desc'        => 'Solid wood joinery, finishing, upholstery, and QC.',
			'step5_title'       => 'Delivery',
			'step5_desc'        => 'Export-grade packaging, shipping, and site installation.',

			// Materials
			'mat_eyebrow'       => 'HERITAGE CRAFTS',
			'mat_title'         => 'Vocabularies under one roof.',
			'mat_desc'          => 'Combining traditional woodworking, and metalwork with modern hardware.',

			// Bottom CTA Band
			'band_title'        => 'Tell us what you\'re building.',
			'band_desc'         => 'Send your BOQ or architectural drawings. Our project desk replies with formal pricing, lead time, and freight within 24 working hours.',
			'band_cta1_text'    => 'Start an enquiry →',
			'band_cta1_url'     => '/contact',
			'band_cta2_text'    => 'Explore 2026 Collections',
			'band_cta2_url'     => '/collections',
		);

		$saved = get_option( 'hcc_homepage_options', array() );
		$data  = wp_parse_args( $saved, $defaults );

		// Auto-migrate legacy /catalogue URLs to /collections
		if ( isset( $data['band_cta2_url'] ) && ( '/catalogue' === $data['band_cta2_url'] || empty( $data['band_cta2_url'] ) ) ) {
			$data['band_cta2_url'] = '/collections';
		}
		if ( isset( $data['band_cta2_text'] ) && stripos( $data['band_cta2_text'], 'catalogue' ) !== false ) {
			$data['band_cta2_text'] = str_ireplace( 'catalogue', 'Collections', $data['band_cta2_text'] );
		}
		if ( isset( $data['cat_eyebrow'] ) && stripos( $data['cat_eyebrow'], 'catalogue' ) !== false ) {
			$data['cat_eyebrow'] = str_ireplace( 'CATALOGUE', 'COLLECTIONS', $data['cat_eyebrow'] );
		}

		return $data;
	}

	public static function render_homepage_builder_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$data = self::get_homepage_data();
		?>
		<div class="wrap" style="max-width:1100px; margin-top:20px;">
			<h1 style="font-size:24px; font-weight:700; margin-bottom:6px;">Homepage Content Builder & Section Manager</h1>
			<p style="color:#666; font-size:14px; margin-bottom:24px;">
				Edit any text, heading, paragraph, stat, point, or button link on your Next.js storefront homepage. All changes sync instantly over REST API.
			</p>

			<form method="post" action="options.php">
				<?php settings_fields( 'hcc_homepage_options_group' ); ?>

				<!-- SECTION: HERO & STATS -->
				<div class="postbox" style="padding:20px; margin-bottom:24px; background:#fff; border:1px solid #c3c4c7; border-radius:6px;">
					<h2 style="font-size:18px; font-weight:700; border-bottom:1px solid #eee; padding-bottom:10px; margin-top:0; color:#0E5C63;">
						1. Hero Section & Statistics
					</h2>
					<div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-top:16px;">
						<div>
							<label style="font-weight:600; display:block; margin-bottom:4px;">Hero Eyebrow Badge:</label>
							<input type="text" name="hcc_homepage_options[hero_eyebrow]" value="<?php echo esc_attr( $data['hero_eyebrow'] ); ?>" style="width:100%;" />
						</div>
						<div>
							<label style="font-weight:600; display:block; margin-bottom:4px;">Hero Accent Word (Highlighted in Teal):</label>
							<input type="text" name="hcc_homepage_options[hero_accent]" value="<?php echo esc_attr( $data['hero_accent'] ); ?>" style="width:100%;" />
						</div>
					</div>

					<div style="margin-top:16px;">
						<label style="font-weight:600; display:block; margin-bottom:4px;">Hero Main Headline:</label>
						<input type="text" name="hcc_homepage_options[hero_title]" value="<?php echo esc_attr( $data['hero_title'] ); ?>" style="width:100%; font-size:16px;" />
					</div>

					<div style="margin-top:16px;">
						<label style="font-weight:600; display:block; margin-bottom:4px;">Hero Paragraph Description:</label>
						<textarea name="hcc_homepage_options[hero_lede]" rows="3" style="width:100%;"><?php echo esc_textarea( $data['hero_lede'] ); ?></textarea>
					</div>

					<div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-top:16px;">
						<div>
							<label style="font-weight:600; display:block; margin-bottom:4px;">Primary CTA Button Text:</label>
							<input type="text" name="hcc_homepage_options[hero_cta1_text]" value="<?php echo esc_attr( $data['hero_cta1_text'] ?? 'EXPLORE THE COLLECTION' ); ?>" style="width:100%;" />
							<label style="font-size:11px; color:#666; display:block; margin-top:4px;">Button Link (e.g. /collections):</label>
							<input type="text" name="hcc_homepage_options[hero_cta1_url]" value="<?php echo esc_attr( $data['hero_cta1_url'] ?? '/collections' ); ?>" style="width:100%;" />
						</div>
						<div>
							<label style="font-weight:600; display:block; margin-bottom:4px;">Secondary Action Link Text:</label>
							<input type="text" name="hcc_homepage_options[hero_cta2_text]" value="<?php echo esc_attr( $data['hero_cta2_text'] ?? 'DISCOVER OUR CRAFT' ); ?>" style="width:100%;" />
							<label style="font-size:11px; color:#666; display:block; margin-top:4px;">Link URL (e.g. /about):</label>
							<input type="text" name="hcc_homepage_options[hero_cta2_url]" value="<?php echo esc_attr( $data['hero_cta2_url'] ?? '/about' ); ?>" style="width:100%;" />
						</div>
					</div>

					<div style="margin-top:16px; background:#f9f9f9; padding:14px; border-radius:6px; border:1px solid #e5e5e5;">
						<h3 style="margin-top:0; font-size:14px; color:#0E5C63;">Hero Background Style & Color Settings</h3>
						<div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-top:10px;">
							<div>
								<label style="font-weight:600; display:block; margin-bottom:4px;">Background Style Mode:</label>
								<select name="hcc_homepage_options[hero_bg_mode]" style="width:100%; font-size:13px;">
									<option value="image" <?php selected( $data['hero_bg_mode'], 'image' ); ?>>Background Image (Media Library)</option>
									<option value="color" <?php selected( $data['hero_bg_mode'], 'color' ); ?>>Solid Background Color Only</option>
								</select>
							</div>
							<div>
								<label style="font-weight:600; display:block; margin-bottom:4px;">Solid Background Color (Hex):</label>
								<input type="text" name="hcc_homepage_options[hero_bg_color]" value="<?php echo esc_attr( $data['hero_bg_color'] ); ?>" style="width:100%;" placeholder="#181512" />
							</div>
						</div>

						<div style="display:grid; grid-template-columns:2fr 1fr; gap:16px; margin-top:12px;">
							<div>
								<label style="font-weight:600; display:block; margin-bottom:4px;">Background Image URL (WordPress Media Library):</label>
								<input type="text" name="hcc_homepage_options[hero_bg_image]" value="<?php echo esc_attr( $data['hero_bg_image'] ); ?>" style="width:100%;" placeholder="https://yourdomain.com/wp-content/uploads/hero.jpg" />
							</div>
							<div>
								<label style="font-weight:600; display:block; margin-bottom:4px;">Dark Scrim Opacity (%):</label>
								<input type="number" min="0" max="100" name="hcc_homepage_options[hero_overlay_opacity]" value="<?php echo esc_attr( $data['hero_overlay_opacity'] ); ?>" style="width:100%;" placeholder="85" />
							</div>
						</div>
					</div>

					<h3 style="font-size:14px; font-weight:700; margin-top:20px; color:#333;">Hero Stat Counters (4 Columns):</h3>
					<div style="display:grid; grid-template-columns:repeat(4, 1fr); gap:12px; margin-top:10px;">
						<div>
							<label style="font-size:12px; font-weight:600;">Stat 1 Number:</label>
							<input type="text" name="hcc_homepage_options[stat1_number]" value="<?php echo esc_attr( $data['stat1_number'] ); ?>" style="width:100%;" />
							<label style="font-size:11px; color:#666; display:block; margin-top:4px;">Label:</label>
							<input type="text" name="hcc_homepage_options[stat1_label]" value="<?php echo esc_attr( $data['stat1_label'] ); ?>" style="width:100%;" />
						</div>
						<div>
							<label style="font-size:12px; font-weight:600;">Stat 2 Number:</label>
							<input type="text" name="hcc_homepage_options[stat2_number]" value="<?php echo esc_attr( $data['stat2_number'] ); ?>" style="width:100%;" />
							<label style="font-size:11px; color:#666; display:block; margin-top:4px;">Label:</label>
							<input type="text" name="hcc_homepage_options[stat2_label]" value="<?php echo esc_attr( $data['stat2_label'] ); ?>" style="width:100%;" />
						</div>
						<div>
							<label style="font-size:12px; font-weight:600;">Stat 3 Number:</label>
							<input type="text" name="hcc_homepage_options[stat3_number]" value="<?php echo esc_attr( $data['stat3_number'] ); ?>" style="width:100%;" />
							<label style="font-size:11px; color:#666; display:block; margin-top:4px;">Label:</label>
							<input type="text" name="hcc_homepage_options[stat3_label]" value="<?php echo esc_attr( $data['stat3_label'] ); ?>" style="width:100%;" />
						</div>
						<div>
							<label style="font-size:12px; font-weight:600;">Stat 4 Number:</label>
							<input type="text" name="hcc_homepage_options[stat4_number]" value="<?php echo esc_attr( $data['stat4_number'] ); ?>" style="width:100%;" />
							<label style="font-size:11px; color:#666; display:block; margin-top:4px;">Label:</label>
							<input type="text" name="hcc_homepage_options[stat4_label]" value="<?php echo esc_attr( $data['stat4_label'] ); ?>" style="width:100%;" />
						</div>
					</div>
				</div>

				<!-- SECTION: 2 FEATURE TRACK CARDS -->
				<div class="postbox" style="padding:20px; margin-bottom:24px; background:#fff; border:1px solid #c3c4c7; border-radius:6px;">
					<h2 style="font-size:18px; font-weight:700; border-bottom:1px solid #eee; padding-bottom:10px; margin-top:0; color:#0E5C63;">
						2. Feature Track Cards (Two Audience Split Cards)
					</h2>
					<div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-top:16px;">
						<div style="background:#f9f9f9; padding:14px; border-radius:6px; border:1px solid #e5e5e5;">
							<h3 style="margin-top:0; font-size:14px; color:#0E5C63;">Card 1: Direct Contract Projects</h3>
							<div style="margin-bottom:10px;">
								<label style="font-size:12px; font-weight:600; display:block;">Card 1 Title:</label>
								<input type="text" name="hcc_homepage_options[track1_title]" value="<?php echo esc_attr( $data['track1_title'] ); ?>" style="width:100%;" />
							</div>
							<div style="margin-bottom:10px;">
								<label style="font-size:12px; font-weight:600; display:block;">Card 1 Description:</label>
								<textarea name="hcc_homepage_options[track1_desc]" rows="2" style="width:100%;"><?php echo esc_textarea( $data['track1_desc'] ); ?></textarea>
							</div>
							<div>
								<label style="font-size:12px; font-weight:600; display:block;">Bullet Points (1 per line):</label>
								<textarea name="hcc_homepage_options[track1_points]" rows="4" style="width:100%; font-size:12px;"><?php echo esc_textarea( $data['track1_points'] ); ?></textarea>
							</div>
						</div>

						<div style="background:#f9f9f9; padding:14px; border-radius:6px; border:1px solid #e5e5e5;">
							<h3 style="margin-top:0; font-size:14px; color:#B07A1E;">Card 2: Turnkey Plug-in Packages</h3>
							<div style="margin-bottom:10px;">
								<label style="font-size:12px; font-weight:600; display:block;">Card 2 Title:</label>
								<input type="text" name="hcc_homepage_options[track2_title]" value="<?php echo esc_attr( $data['track2_title'] ); ?>" style="width:100%;" />
							</div>
							<div style="margin-bottom:10px;">
								<label style="font-size:12px; font-weight:600; display:block;">Card 2 Description:</label>
								<textarea name="hcc_homepage_options[track2_desc]" rows="2" style="width:100%;"><?php echo esc_textarea( $data['track2_desc'] ); ?></textarea>
							</div>
							<div>
								<label style="font-size:12px; font-weight:600; display:block;">Bullet Points (1 per line):</label>
								<textarea name="hcc_homepage_options[track2_points]" rows="4" style="width:100%; font-size:12px;"><?php echo esc_textarea( $data['track2_points'] ); ?></textarea>
							</div>
						</div>
					</div>
				</div>

				<!-- SECTION: WORK WITH US (CHOOSE HOW YOU'D LIKE TO WORK WITH US) -->
				<div class="postbox" style="padding:20px; margin-bottom:24px; background:#fff; border:1px solid #c3c4c7; border-radius:6px;">
					<h2 style="font-size:18px; font-weight:700; border-bottom:1px solid #eee; padding-bottom:10px; margin-top:0; color:#0E5C63;">
						2. "Choose How You'd Like to Work With Us" Section (Cards Below Stats)
					</h2>
					<div style="margin-top:16px; margin-bottom:20px;">
						<label style="font-weight:600; display:block; margin-bottom:4px;">Main Section Title:</label>
						<input type="text" name="hcc_homepage_options[work_title]" value="<?php echo esc_attr( $data['work_title'] ?? "Choose How You'd Like to Work With Us" ); ?>" style="width:100%; font-size:15px;" />
					</div>

					<div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
						<!-- CARD 1 -->
						<div style="background:#f9f9f9; padding:16px; border-radius:6px; border:1px solid #e5e5e5;">
							<h3 style="margin-top:0; font-size:15px; color:#A36B3B;">Left Card: Individual Pieces (Shop Furniture)</h3>
							<div style="margin-bottom:10px;">
								<label style="font-size:12px; font-weight:600; display:block;">Eyebrow Tag:</label>
								<input type="text" name="hcc_homepage_options[work_card1_eyebrow]" value="<?php echo esc_attr( $data['work_card1_eyebrow'] ?? 'SHOP FURNITURE' ); ?>" style="width:100%;" />
							</div>
							<div style="margin-bottom:10px;">
								<label style="font-size:12px; font-weight:600; display:block;">Card Heading:</label>
								<input type="text" name="hcc_homepage_options[work_card1_title]" value="<?php echo esc_attr( $data['work_card1_title'] ?? 'Individual Pieces, Made to Belong' ); ?>" style="width:100%;" />
							</div>
							<div style="margin-bottom:10px;">
								<label style="font-size:12px; font-weight:600; display:block;">Description:</label>
								<textarea name="hcc_homepage_options[work_card1_desc]" rows="3" style="width:100%;"><?php echo esc_textarea( $data['work_card1_desc'] ?? 'Discover considered furniture and objects for one room, one corner, or the whole home.' ); ?></textarea>
							</div>
							<div style="margin-bottom:10px;">
								<label style="font-size:12px; font-weight:600; display:block;">Button / Link Text:</label>
								<input type="text" name="hcc_homepage_options[work_card1_cta]" value="<?php echo esc_attr( $data['work_card1_cta'] ?? 'EXPLORE THE COLLECTION' ); ?>" style="width:100%;" />
							</div>
							<div style="margin-bottom:10px;">
								<label style="font-size:12px; font-weight:600; display:block;">Target URL Link:</label>
								<input type="text" name="hcc_homepage_options[work_card1_url]" value="<?php echo esc_attr( $data['work_card1_url'] ?? '/collections' ); ?>" style="width:100%;" />
							</div>
							<div>
								<label style="font-size:12px; font-weight:600; display:block;">Image URL / Path:</label>
								<input type="text" name="hcc_homepage_options[work_card1_image]" value="<?php echo esc_attr( $data['work_card1_image'] ?? '/Explore_collection.webp' ); ?>" style="width:100%;" />
							</div>
						</div>

						<!-- CARD 2 -->
						<div style="background:#f9f9f9; padding:16px; border-radius:6px; border:1px solid #e5e5e5;">
							<h3 style="margin-top:0; font-size:15px; color:#A36B3B;">Right Card: Complete Projects (Trade Desk)</h3>
							<div style="margin-bottom:10px;">
								<label style="font-size:12px; font-weight:600; display:block;">Eyebrow Tag:</label>
								<input type="text" name="hcc_homepage_options[work_card2_eyebrow]" value="<?php echo esc_attr( $data['work_card2_eyebrow'] ?? 'COMPLETE PROJECTS' ); ?>" style="width:100%;" />
							</div>
							<div style="margin-bottom:10px;">
								<label style="font-size:12px; font-weight:600; display:block;">Card Heading:</label>
								<input type="text" name="hcc_homepage_options[work_card2_title]" value="<?php echo esc_attr( $data['work_card2_title'] ?? 'Spaces, Crafted from Brief to Installation' ); ?>" style="width:100%;" />
							</div>
							<div style="margin-bottom:10px;">
								<label style="font-size:12px; font-weight:600; display:block;">Description:</label>
								<textarea name="hcc_homepage_options[work_card2_desc]" rows="3" style="width:100%;"><?php echo esc_textarea( $data['work_card2_desc'] ?? 'Partner with our project team for custom furniture, material development, production and complete execution.' ); ?></textarea>
							</div>
							<div style="margin-bottom:10px;">
								<label style="font-size:12px; font-weight:600; display:block;">Button / Link Text:</label>
								<input type="text" name="hcc_homepage_options[work_card2_cta]" value="<?php echo esc_attr( $data['work_card2_cta'] ?? 'VISIT THE TRADE DESK' ); ?>" style="width:100%;" />
							</div>
							<div style="margin-bottom:10px;">
								<label style="font-size:12px; font-weight:600; display:block;">Target URL Link:</label>
								<input type="text" name="hcc_homepage_options[work_card2_url]" value="<?php echo esc_attr( $data['work_card2_url'] ?? '/discuss-projects' ); ?>" style="width:100%;" />
							</div>
							<div>
								<label style="font-size:12px; font-weight:600; display:block;">Image URL / Path:</label>
								<input type="text" name="hcc_homepage_options[work_card2_image]" value="<?php echo esc_attr( $data['work_card2_image'] ?? '/Project.webp' ); ?>" style="width:100%;" />
							</div>
						</div>
					</div>
				</div>

				<!-- SECTION: HEADINGS FOR CATEGORIES, SPACES, DESIGNS -->
				<div class="postbox" style="padding:20px; margin-bottom:24px; background:#fff; border:1px solid #c3c4c7; border-radius:6px;">
					<h2 style="font-size:18px; font-weight:700; border-bottom:1px solid #eee; padding-bottom:10px; margin-top:0; color:#0E5C63;">
						3. Section Headings & Descriptions
					</h2>
					<div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-top:16px;">
						<div>
							<h3 style="font-size:14px; margin-top:0;">Categories Section Header:</h3>
							<label style="font-size:11px; color:#666;">Eyebrow:</label>
							<input type="text" name="hcc_homepage_options[cat_eyebrow]" value="<?php echo esc_attr( $data['cat_eyebrow'] ); ?>" style="width:100%; margin-bottom:8px;" />
							<label style="font-size:11px; color:#666;">Heading:</label>
							<input type="text" name="hcc_homepage_options[cat_title]" value="<?php echo esc_attr( $data['cat_title'] ); ?>" style="width:100%; margin-bottom:8px;" />
							<label style="font-size:11px; color:#666;">Description:</label>
							<textarea name="hcc_homepage_options[cat_desc]" rows="2" style="width:100%;"><?php echo esc_textarea( $data['cat_desc'] ); ?></textarea>
						</div>

						<div>
							<h3 style="font-size:14px; margin-top:0;">Project Domains / Spaces Header:</h3>
							<label style="font-size:11px; color:#666;">Eyebrow:</label>
							<input type="text" name="hcc_homepage_options[seg_eyebrow]" value="<?php echo esc_attr( $data['seg_eyebrow'] ); ?>" style="width:100%; margin-bottom:8px;" />
							<label style="font-size:11px; color:#666;">Heading:</label>
							<input type="text" name="hcc_homepage_options[seg_title]" value="<?php echo esc_attr( $data['seg_title'] ); ?>" style="width:100%; margin-bottom:8px;" />
							<label style="font-size:11px; color:#666;">Description:</label>
							<textarea name="hcc_homepage_options[seg_desc]" rows="2" style="width:100%;"><?php echo esc_textarea( $data['seg_desc'] ); ?></textarea>
						</div>
					</div>

					<div style="margin-top:20px; border-top:1px solid #eee; padding-top:16px;">
						<h3 style="font-size:14px; margin-top:0;">Featured Designs Header:</h3>
						<div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
							<div>
								<label style="font-size:11px; color:#666;">Eyebrow:</label>
								<input type="text" name="hcc_homepage_options[feat_eyebrow]" value="<?php echo esc_attr( $data['feat_eyebrow'] ); ?>" style="width:100%; margin-bottom:8px;" />
								<label style="font-size:11px; color:#666;">Heading:</label>
								<input type="text" name="hcc_homepage_options[feat_title]" value="<?php echo esc_attr( $data['feat_title'] ); ?>" style="width:100%;" />
							</div>
							<div>
								<label style="font-size:11px; color:#666;">Description:</label>
								<textarea name="hcc_homepage_options[feat_desc]" rows="3" style="width:100%;"><?php echo esc_textarea( $data['feat_desc'] ); ?></textarea>
							</div>
						</div>
					</div>
				<!-- SECTION: PROJECT DOMAINS / CATEGORIES (4 CARDS) -->
				<div class="postbox" style="padding:20px; margin-bottom:24px; background:#fff; border:1px solid #c3c4c7; border-radius:6px;">
					<h2 style="font-size:18px; font-weight:700; border-bottom:1px solid #eee; padding-bottom:10px; margin-top:0; color:#0E5C63;">
						4. Project Category Cards (4 Homepage Project Domains)
					</h2>
					<p style="color:#666; font-size:13px; margin-bottom:16px;">
						Customize the title, destination URL, and image for each of the 4 project category spaces shown on the homepage. You can paste any image URL from your WordPress Media Library (e.g. <code>https://yourdomain.com/wp-content/uploads/...</code>) or use a local path.
					</p>
					<div style="display:grid; grid-template-columns:repeat(2, 1fr); gap:16px;">
						<!-- CARD 1 -->
						<div style="background:#f9f9f9; padding:14px; border-radius:6px; border:1px solid #e5e5e5;">
							<h3 style="margin-top:0; font-size:14px; color:#0E5C63;">Card 1: Hotel Guestrooms</h3>
							<div style="margin-bottom:8px;">
								<label style="font-size:12px; font-weight:600; display:block;">Card Title:</label>
								<input type="text" name="hcc_homepage_options[seg1_name]" value="<?php echo esc_attr( $data['seg1_name'] ?? 'Hotel Guestrooms' ); ?>" style="width:100%;" />
							</div>
							<div style="margin-bottom:8px;">
								<label style="font-size:12px; font-weight:600; display:block;">Target URL:</label>
								<input type="text" name="hcc_homepage_options[seg1_url]" value="<?php echo esc_attr( $data['seg1_url'] ?? '/collections?seg=Hotel%20Guestrooms' ); ?>" style="width:100%;" />
							</div>
							<div>
								<label style="font-size:12px; font-weight:600; display:block;">Image URL (WordPress Media):</label>
								<input type="text" name="hcc_homepage_options[seg1_image]" value="<?php echo esc_attr( $data['seg1_image'] ?? '/project-categories/hotel-guestrooms.webp' ); ?>" style="width:100%;" placeholder="/project-categories/hotel-guestrooms.webp" />
							</div>
						</div>

						<!-- CARD 2 -->
						<div style="background:#f9f9f9; padding:14px; border-radius:6px; border:1px solid #e5e5e5;">
							<h3 style="margin-top:0; font-size:14px; color:#0E5C63;">Card 2: Hotel Lobby</h3>
							<div style="margin-bottom:8px;">
								<label style="font-size:12px; font-weight:600; display:block;">Card Title:</label>
								<input type="text" name="hcc_homepage_options[seg2_name]" value="<?php echo esc_attr( $data['seg2_name'] ?? 'Hotel Lobby' ); ?>" style="width:100%;" />
							</div>
							<div style="margin-bottom:8px;">
								<label style="font-size:12px; font-weight:600; display:block;">Target URL:</label>
								<input type="text" name="hcc_homepage_options[seg2_url]" value="<?php echo esc_attr( $data['seg2_url'] ?? '/collections?seg=Hotel%20Lobby' ); ?>" style="width:100%;" />
							</div>
							<div>
								<label style="font-size:12px; font-weight:600; display:block;">Image URL (WordPress Media):</label>
								<input type="text" name="hcc_homepage_options[seg2_image]" value="<?php echo esc_attr( $data['seg2_image'] ?? '/project-categories/hotel-lobby.webp' ); ?>" style="width:100%;" placeholder="/project-categories/hotel-lobby.webp" />
							</div>
						</div>

						<!-- CARD 3 -->
						<div style="background:#f9f9f9; padding:14px; border-radius:6px; border:1px solid #e5e5e5;">
							<h3 style="margin-top:0; font-size:14px; color:#0E5C63;">Card 3: Restaurant</h3>
							<div style="margin-bottom:8px;">
								<label style="font-size:12px; font-weight:600; display:block;">Card Title:</label>
								<input type="text" name="hcc_homepage_options[seg3_name]" value="<?php echo esc_attr( $data['seg3_name'] ?? 'Restaurant' ); ?>" style="width:100%;" />
							</div>
							<div style="margin-bottom:8px;">
								<label style="font-size:12px; font-weight:600; display:block;">Target URL:</label>
								<input type="text" name="hcc_homepage_options[seg3_url]" value="<?php echo esc_attr( $data['seg3_url'] ?? '/collections?seg=Restaurant' ); ?>" style="width:100%;" />
							</div>
							<div>
								<label style="font-size:12px; font-weight:600; display:block;">Image URL (WordPress Media):</label>
								<input type="text" name="hcc_homepage_options[seg3_image]" value="<?php echo esc_attr( $data['seg3_image'] ?? '/project-categories/restaurant.webp' ); ?>" style="width:100%;" placeholder="/project-categories/restaurant.webp" />
							</div>
						</div>

						<!-- CARD 4 -->
						<div style="background:#f9f9f9; padding:14px; border-radius:6px; border:1px solid #e5e5e5;">
							<h3 style="margin-top:0; font-size:14px; color:#0E5C63;">Card 4: Café & Bistro</h3>
							<div style="margin-bottom:8px;">
								<label style="font-size:12px; font-weight:600; display:block;">Card Title:</label>
								<input type="text" name="hcc_homepage_options[seg4_name]" value="<?php echo esc_attr( $data['seg4_name'] ?? 'Café & Bistro' ); ?>" style="width:100%;" />
							</div>
							<div style="margin-bottom:8px;">
								<label style="font-size:12px; font-weight:600; display:block;">Target URL:</label>
								<input type="text" name="hcc_homepage_options[seg4_url]" value="<?php echo esc_attr( $data['seg4_url'] ?? '/collections?seg=Caf%C3%A9%20%26%20Bistro' ); ?>" style="width:100%;" />
							</div>
							<div>
								<label style="font-size:12px; font-weight:600; display:block;">Image URL (WordPress Media):</label>
								<input type="text" name="hcc_homepage_options[seg4_image]" value="<?php echo esc_attr( $data['seg4_image'] ?? '/project-categories/cafe-bistro.webp' ); ?>" style="width:100%;" placeholder="/project-categories/cafe-bistro.webp" />
							</div>
						</div>
					</div>
				</div>

				<!-- SECTION: 5 STEPS & BOTTOM CTA -->
				<div class="postbox" style="padding:20px; margin-bottom:24px; background:#fff; border:1px solid #c3c4c7; border-radius:6px;">
					<h2 style="font-size:18px; font-weight:700; border-bottom:1px solid #eee; padding-bottom:10px; margin-top:0; color:#0E5C63;">
						5. Factory 5-Step Process & Bottom Banner Callout
					</h2>
					<div style="margin-top:14px;">
						<label style="font-weight:600; font-size:12px;">5-Step Process Heading:</label>
						<input type="text" name="hcc_homepage_options[step_title]" value="<?php echo esc_attr( $data['step_title'] ); ?>" style="width:100%; margin-bottom:12px;" />

						<div style="display:grid; grid-template-columns:repeat(5, 1fr); gap:10px;">
							<?php for ( $i = 1; $i <= 5; $i ++ ) : ?>
								<div style="background:#f9f9f9; padding:10px; border-radius:4px; border:1px solid #eee;">
									<strong style="font-size:12px; display:block; color:#0E5C63;">Step <?php echo $i; ?></strong>
									<input type="text" name="hcc_homepage_options[step<?php echo $i; ?>_title]" value="<?php echo esc_attr( $data[ "step{$i}_title" ] ); ?>" style="width:100%; margin:4px 0;" placeholder="Title" />
									<textarea name="hcc_homepage_options[step<?php echo $i; ?>_desc]" rows="3" style="width:100%; font-size:11px;" placeholder="Description"><?php echo esc_textarea( $data[ "step{$i}_desc" ] ); ?></textarea>
								</div>
							<?php endfor; ?>
						</div>
					</div>

					<div style="margin-top:20px; border-top:1px solid #eee; padding-top:16px;">
						<h3 style="font-size:14px; margin-top:0; color:#0E5C63;">Bottom Banner Callout:</h3>
						<div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
							<div>
								<label style="font-size:11px; color:#666;">Banner Title:</label>
								<input type="text" name="hcc_homepage_options[band_title]" value="<?php echo esc_attr( $data['band_title'] ); ?>" style="width:100%; margin-bottom:8px;" />
								<label style="font-size:11px; color:#666;">Banner Description:</label>
								<textarea name="hcc_homepage_options[band_desc]" rows="2" style="width:100%;"><?php echo esc_textarea( $data['band_desc'] ); ?></textarea>
							</div>
							<div>
								<label style="font-size:11px; color:#666;">Primary CTA Text & URL:</label>
								<div style="display:flex; gap:6px; margin-bottom:8px;">
									<input type="text" name="hcc_homepage_options[band_cta1_text]" value="<?php echo esc_attr( $data['band_cta1_text'] ); ?>" placeholder="Text" style="flex:1;" />
									<input type="text" name="hcc_homepage_options[band_cta1_url]" value="<?php echo esc_attr( $data['band_cta1_url'] ); ?>" placeholder="URL" style="flex:1;" />
								</div>
								<label style="font-size:11px; color:#666;">Secondary CTA Text & URL:</label>
								<div style="display:flex; gap:6px;">
									<input type="text" name="hcc_homepage_options[band_cta2_text]" value="<?php echo esc_attr( $data['band_cta2_text'] ); ?>" placeholder="Text" style="flex:1;" />
									<input type="text" name="hcc_homepage_options[band_cta2_url]" value="<?php echo esc_attr( $data['band_cta2_url'] ); ?>" placeholder="URL" style="flex:1;" />
								</div>
							</div>
						</div>
					</div>
				<div style="display:flex; align-items:center; gap:12px; margin-top:20px;">
					<?php submit_button( 'Save Homepage Content', 'primary', 'submit', false ); ?>
					<a href="<?php echo esc_url( \HeadlessCommerceCore\Admin\BusinessPagesManager::get_frontend_url() ); ?>" target="_blank" class="button button-secondary" style="font-weight:600; padding:4px 14px;">
						👁️ View Live Storefront ↗
					</a>
				</div>
			</form>
		</div>
		<?php
	}
}
